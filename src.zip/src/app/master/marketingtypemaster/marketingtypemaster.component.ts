import { RestService } from './../../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import {AfterViewInit, Component, ViewChild} from '@angular/core';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { FormGroup,FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-marketingtypemaster',
  templateUrl: './marketingtypemaster.component.html',
  styleUrls: ['./marketingtypemaster.component.css']
})
export class MarketingtypemasterComponent {
  displayedColumns: string[] = ['Sr No.', 'Marketing Type', 'Action'];
  dataSource = new MatTableDataSource<marketingmasterList>;
  marketingmasterlist:marketingmasterList [] = [];
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  marketingmasterform = new FormGroup({
    id : new FormControl(0),
    marketing_type: new FormControl(''),
  })
  constructor(public rest: RestService) {

  }

  submit(){
    
  }
  // 
  // this.dataSource = new MatTableDataSource(this.inwardList);
  // this.dataSource.paginator = this.paginator;

}

export interface marketingmasterList {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}
