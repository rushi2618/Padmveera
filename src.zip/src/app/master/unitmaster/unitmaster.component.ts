import { RestService } from './../../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import {AfterViewInit, Component, ViewChild} from '@angular/core';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { FormGroup,FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-unitmaster',
  templateUrl: './unitmaster.component.html',
  styleUrls: ['./unitmaster.component.css']
})
export class UnitmasterComponent {
  displayedColumns: string[] = ['Sr No.', 'Unit', 'Action'];
  dataSource = new MatTableDataSource<unitmasterList>;
  unitmasterlist:unitmasterList [] = [];
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  unitmasterform = new FormGroup({
    id : new FormControl(0),
    unit : new FormControl(''),
  })
  constructor(public rest: RestService) {

  }

  submit(){
    
  }
  // 
  // this.dataSource = new MatTableDataSource(this.inwardList);
  // this.dataSource.paginator = this.paginator;

}

export interface unitmasterList {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}
