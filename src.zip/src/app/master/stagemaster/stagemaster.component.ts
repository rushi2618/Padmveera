import { RestService } from './../../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import {AfterViewInit, Component, ViewChild} from '@angular/core';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { FormGroup,FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-stagemaster',
  templateUrl: './stagemaster.component.html',
  styleUrls: ['./stagemaster.component.css']
})
export class StagemasterComponent {
  displayedColumns: string[] = ['Stage No.', 'Stage Name', 'Action'];
  dataSource = new MatTableDataSource<materialList>;
  materiallist:materialList [] = [];
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  stagemasterform = new FormGroup({
    id : new FormControl(0),
    material_name : new FormControl(''),
  })
  constructor(public rest: RestService) {

  }

  submit(){
    
  }
  // 
  // this.dataSource = new MatTableDataSource(this.inwardList);
  // this.dataSource.paginator = this.paginator;

}

export interface materialList {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}


