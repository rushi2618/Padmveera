import { RestService } from './../../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import {AfterViewInit, Component, ViewChild} from '@angular/core';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { FormGroup,FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-usermaster',
  templateUrl: './usermaster.component.html',
  styleUrls: ['./usermaster.component.css']
})
export class UsermasterComponent {
  displayedColumns: string[] = ['Sr No.', 'User Name', 'Email Id','Role','Mobile No', 'Action'];
  dataSource = new MatTableDataSource<usermasterList>;
  usermasterlist:usermasterList [] = [];
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  usermasterform = new FormGroup({
    id : new FormControl(0),
    username : new FormControl(''),
    email : new FormControl(''),
    mobile:new FormControl(''),
    role : new FormControl('')
  })
  constructor(public rest: RestService) {

  }

  submit(){
    
  }
  // 
  // this.dataSource = new MatTableDataSource(this.inwardList);
  // this.dataSource.paginator = this.paginator;

}

export interface usermasterList {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}
