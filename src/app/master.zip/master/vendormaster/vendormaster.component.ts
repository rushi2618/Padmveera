import { RestService } from './../../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import {AfterViewInit, Component, ViewChild} from '@angular/core';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { FormGroup,FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-vendormaster',
  templateUrl: './vendormaster.component.html',
  styleUrls: ['./vendormaster.component.css']
})
export class VendormasterComponent {
  displayedColumns: string[] = ['ID', 'Vendor Name','Vendor Phone No.','Address','Material Name', 'Action'];
  dataSource = new MatTableDataSource<vendormasterList>;
  vendormasterlist:vendormasterList [] = [];
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  vendormasterform = new FormGroup({
    id : new FormControl(0),
    vendorname : new FormControl(''),
    vendorphone:new FormControl(''),
    vendoradd : new FormControl(''),
    materialname:new FormControl('')
  })
  constructor(public rest: RestService) {

  }

  submit(){
    
  }
  // 
  // this.dataSource = new MatTableDataSource(this.inwardList);
  // this.dataSource.paginator = this.paginator;

}

export interface vendormasterList {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}
