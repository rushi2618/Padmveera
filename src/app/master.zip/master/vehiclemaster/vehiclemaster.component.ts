import { RestService } from './../../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import {AfterViewInit, Component, ViewChild} from '@angular/core';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { FormGroup,FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-vehiclemaster',
  templateUrl: './vehiclemaster.component.html',
  styleUrls: ['./vehiclemaster.component.css']
})
export class VehiclemasterComponent {
  displayedColumns: string[] = ['Sr No.', 'Vehicle Name', 'Action'];
  dataSource = new MatTableDataSource<vehiclemasterList>;
  vehiclemasterlist:vehiclemasterList [] = [];
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  vehiclemasterform = new FormGroup({
    id : new FormControl(0),
    vehicle_name : new FormControl('')
  })
  constructor(public rest: RestService) {

  }

  submit(){
    
  }
  // 
  // this.dataSource = new MatTableDataSource(this.inwardList);
  // this.dataSource.paginator = this.paginator;

}

export interface vehiclemasterList {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}
