import { RestService } from './../../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import {AfterViewInit, Component, ViewChild} from '@angular/core';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { FormGroup,FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-accountmainledger',
  templateUrl: './accountmainledger.component.html',
  styleUrls: ['./accountmainledger.component.css']
})
export class AccountmainledgerComponent {
  displayedColumns: string[] = ['Sr No.', 'Main Ledger', 'Type','Description', 'Action'];
  dataSource = new MatTableDataSource<mainledgerList>;
  mainledgerlist:mainledgerList [] = [];
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  mainledgerform = new FormGroup({
    id : new FormControl(0),
    mainledger : new FormControl(''),
    type : new FormControl(''),
    desc:new FormControl('')
  })
  constructor(public rest: RestService) {

  }

  submit(){
    
  }
  // 
  // this.dataSource = new MatTableDataSource(this.inwardList);
  // this.dataSource.paginator = this.paginator;

}

export interface mainledgerList {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}


