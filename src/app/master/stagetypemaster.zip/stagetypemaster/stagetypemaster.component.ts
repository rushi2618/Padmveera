import { RestService } from './../../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import {AfterViewInit, Component, ViewChild} from '@angular/core';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { FormGroup,FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-stagetypemaster',
  templateUrl: './stagetypemaster.component.html',
  styleUrls: ['./stagetypemaster.component.css']
})
export class StagetypemasterComponent {

  displayedColumns: string[] = ['Sr No.', 'Stage', 'Stage Type', 'Action'];
  dataSource = new MatTableDataSource<stagetypemasterList>;
  stagetypemasterlist:stagetypemasterList [] = [];
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  stagetypemasterform = new FormGroup({
    id : new FormControl(0),
    stage:new FormControl(''),
    type : new FormControl(''),
    
  })
  constructor(public rest: RestService) {

  }

  submit(){
    
  }
  // 
  // this.dataSource = new MatTableDataSource(this.inwardList);
  // this.dataSource.paginator = this.paginator;

}

export interface stagetypemasterList {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}
