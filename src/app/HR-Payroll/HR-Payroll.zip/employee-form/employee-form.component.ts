import { RestService } from './../../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import {AfterViewInit, Component, ViewChild} from '@angular/core';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { FormGroup,FormControl,Validators } from '@angular/forms';


@Component({
  selector: 'app-employee-form',
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.css']
})
export class EmployeeFormComponent {

  displayedColumns: string[] = ['Sr.No', 'Bank Name','Branch Name','Account No','IFSC Code','Opening Balance', 'Action'];
  dataSource = new MatTableDataSource<employeeformList>;
  employeeformlist:employeeformList [] = [];
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  employeeformform = new FormGroup({
    id : new FormControl(0),
    e_name: new FormControl(''),
    email_id:new FormControl(''),
    contact_no : new FormControl(''),
    emergency_contact_no:new FormControl(''),
    designation: new FormControl(''),
    joining_date:new FormControl(''),
    dob : new FormControl(''),
    salary:new FormControl(''),
    gender:new FormControl(''),
    address:new FormControl(''),
    aadhar_no : new FormControl(''),
    pan_no:new FormControl(''),
    bankname:new FormControl(''),
    branchname:new FormControl(''),
    accountno : new FormControl(''),
    ifsc:new FormControl('')
  })
  constructor(public rest: RestService) {

  }

  submit(){
    
  }
  // 
  // this.dataSource = new MatTableDataSource(this.inwardList);
  // this.dataSource.paginator = this.paginator;

}

export interface employeeformList {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}
